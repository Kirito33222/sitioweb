<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Obligatorio para que trabaje diseño web responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

 
    <!-- Enlazar el archivo con la hoja de estilos -->
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- Enlazar con la libreria de iconos fontawesome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="shortcut icon" href="imagenes/favicon32x32.png" type="image/x-icon">
</head>
<body>
    <!-- Cabecera del sitio -->
    <header id="cabecera">
        <!-- Contenedor  -->
        <div class="contenedor" >
            <div class="barra-top">
                <div class="logo">
                    <img src="imagenes/BARRISTAR.JPG" class="ajustar_img">
                </div><!-- Fin de logo-->

                <!-- Barra de menu principal  -->
                <nav id="menu">
                <!-- Contenedor -->
                    <div class="contenedor">
                        <ul class="menu_barra">
                            <li><a href="index.php">Inicio</a></a></li>
                            <li><a href="#servicios">Servicios</a></li>
                            <li><a href="#equipo">Abogados</a></li>
                            <li><a href="#casos">Casos</a></li>
                            <li><a href="#contactanos">Contáctanos</a></li>
                            <li><a href="tramites.php">Tramites</a></li>
                        </ul>
                    </div><!-- Fin de contenedor -->
                 </nav><!-- Fin de barra de menu principal  -->
            </div><!-- Fin de Barra top -->
        </div> <!-- Fin de contenedor  -->
    </header><!-- Fin de la cabecera del sitio -->

    <!-- Sobre nosotros -->
    <section id="nosotros" class="espacio">

        <!-- Contenedor  -->
        <div class="contenedor">
            <!-- Fila -->
            <div class="fila">
            
                 <!-- Columna izquierda -->
                <div class="columna">
                    <img src="imagenes/autoridad_rector.jpg" >
                </div><!-- Fin de columna izquierda -->
            
                <!-- Columna derecha -->
                <div class="columna">
                    <h2> <b>SOBRE NOSOTROS</b></h2>
                    <p>Somos un estudio con 12 años experiencia brindando servicios profesionales. El equipo tiene su objetivo en la defensa en litigios como a la asesoría preventiva en los ámbitos de las decisiones públicas y privadas. Tenemos años de experiencia
                        en la defensa legal de empresas públicas y privadas, así como funcionarios públicos y privados. Bajo nuestro lema “es mejor prevenir, que litigar”.</p>
                    <h3>Pasos para contratarnos</h3>
                        <ol>
                            <li>Envia un correo a buffetbarrista@outlook.pe</li>
                            <li>Pagar los derechos de inscripción.</li>
                            <li>Redactar el problema legal que tiene.</li>
                            <li>Acercarse a en nuestro local para la contrata.</li>
                        </ol>
                </div><!-- Fin de columna derecha -->
            </div><!-- Fin de fila -->
        </div> <!-- Fin de contenedor  -->
    </section><!-- fin de sobre nosotros -->
    
    <!-- Nuestro servicio -->
    <section id="servicios" class="espacio">
        <!-- Contenedor  -->        
        <div class="contenedor">
            <h4>Área de Práctica </h4> 
            <h2><b> Como podemos ayudarte </b></h2>

            <!-- Fila -->
            <div class="fila">

                <!-- Columna izquierda -->
                <div>
                    <img src="imagenes/familia.JPG" >
                </div>
                <div class="columna">
                    <h3><u> Ley familiar</u></h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit magni dicta ratione, sequi iste aperiam consequuntur doloremque earum officia amet sapiente omnis magnam eaque autem, qui illum, maxime placeat obcaecati!</p>
                </div><!-- Fin de columna izquierda -->

                <!-- Columna del medio -->
                <div>
                    <img src="imagenes/lesiones.JPG" alt="Imagen no existe">
                </div>
                <div class="columna">
                    <h3><u>Lesiones Personales</u></h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam quibusdam sunt excepturi sed labore commodi voluptate dicta iure hic temporibus debitis, vitae aperiam et impedit? Minima libero omnis aliquam aut!</p>
                </div><!-- Fin de columna del medio -->

                <!-- Columna derecha -->
                <div>
                    <img src="imagenes/empresarial.JPG" alt="Imagen no existe">
                </div>
                <div class="columna">
                    <h3><u>Derecho administrativo</u></h3>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Maiores praesentium aut quis in rerum nesciunt voluptate, amet dolore odit doloribus fuga ea reiciendis quasi, quibusdam sunt at, necessitatibus asperiores qui?</p>
                </div><!-- Fin del columna derecha -->

            </div><!-- Fin de fila -->
            <!-- Fila -->
            <div class="fila">

                <!-- Columna izquierda -->
                <div>
                    <img src="imagenes/penal.JPG" alt="Imagen no existe">
                </div>
                <div class="columna">
                    <h3><u> Derecho penal</u></h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit magni dicta ratione, sequi iste aperiam consequuntur doloremque earum officia amet sapiente omnis magnam eaque autem, qui illum, maxime placeat obcaecati!</p>
                </div><!-- Fin de columna izquierda -->

                <!-- Columna del medio -->
                <div>
                    <img src="imagenes/educacion.JPG" alt="Imagen no existe"> 
                </div>
                <div class="columna">
                    <h3><u> Ley de educación</u></h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam quibusdam sunt excepturi sed labore commodi voluptate dicta iure hic temporibus debitis, vitae aperiam et impedit? Minima libero omnis aliquam aut!</p>
                </div><!-- Fin de columna del medio -->

                <!-- Columna derecha -->
                <div>
                    <img src="imagenes/inmobiliaria.JPG" alt="Imagen no existe"> 
                </div>
                <div class="columna">
                    <h3><u>Derecho inmobiliario</u></h3>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Maiores praesentium aut quis in rerum nesciunt voluptate, amet dolore odit doloribus fuga ea reiciendis quasi, quibusdam sunt at, necessitatibus asperiores qui?</p>
                </div><!-- Fin del columna derecha -->
            </div><!-- Fin de fila -->
        </div><!-- Fin de contenedor  -->
    </section><!-- Fin de nuestro servicio -->
 
    <!-- Nuestro equipo-->
    <section id="equipo" class="espacio">
        <h2><b> Nuestros Abogados </b></h2>
        <!-- Contenedor -->
        <div class="contenedor2">
            <!-- Columna izquierda -->
            <div class="card">
                <img src="imagenes/abogado1.jpg" >
                <div class="contenido">
                <h3>Luis Miguel Mayhua Quispe</h3>
                <p>Abogado de negocios</p>
                <a href="#">Leer Mas</a>
               </div>
            </div><!-- Fin de columna izquierda -->
            <!-- Columna del medio -->
            <div class="card">
                    <img src="imagenes/abogada2.jpg" >
                <div class="contenido">
                <h3>Natali Rocio Mucha Yarasca</h3>
                <p>Abogado de familia</p>
                <a href="#">Leer Mas</a>
                </div><!-- Fin de columna del medio -->
            </div>
            <!-- Columna derecha  -->
            <div class="card">
                <figure>
                    <img src="imagenes/abogado3.jpg" >
                </figure> 
                <div class="contenido">
                <h3>Jaqueline Erika Surichaqui Quispe</h3>
                <p>Abogado penalista</p>
                <a href="#">Leer Mas</a>
                </div>
            </div><!-- Fin de columna derecha  -->
        </div><!-- Fin de contenedor -->
    
    </section><!-- Fin de nuestro equipo-->

    <!-- Casos  -->
    <section id="casos" class="espacio">  
        <h2> <b>CASOS</b> </h2>
        <!-- Contenedor  -->
        <div class="contenedor">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis, autem delectus cumque, pariatur officia soluta ratione nesciunt similique eveniet iste cupiditate at. Fugiat repellendus corporis, et animi, unde impedit iste excepturi iure natus sequi nobis blanditiis esse, officia explicabo cupiditate quibusdam a quisquam culpa sapiente! Adipisci maiores qui voluptatum, exercitationem magnam at facilis ducimus, sunt ab dolores nostrum porro sed deserunt provident voluptatem quod commodi? Sed vitae placeat ipsum quis enim quisquam minus eligendi corrupti. Ipsum est consectetur voluptas natus et, facilis tempore architecto, quis illum, magnam corrupti quam. Temporibus eius laboriosam totam delectus minima voluptatem iste similique eum sint!</p>
            <img src="imagenes/juicio.jpg" alt="ajustaimg">
        </div> <!--Fin de contenedor-->
    </section> <!-- Fin de casos -->
    </section>
    <!-- Para contactarnos -->
    <section id="contactanos" class="espacio">
        <h2> <b>CONTÁCTANOS</b></h2>
        <!-- Contenedor -->
        <div class="contenedor">

            <!-- Fila -->
            <div class="fila">

                <!-- Columna izquierda -->
                <div class="columna">
                    <h3>Nuestros Contactos</h3>
                    <p> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iure quam impedit pariatur. Dicta voluptates quisquam molestiae officiis soluta hic tempore, nostrum ducimus error fugiat quos sit reprehenderit expedita vero corporis.</p>
                    <h3>Dirección</h3>
                    <p> JR. 2 DE MAYO N°318–EL TAMBO–JUNÍN </p>
                    <h3>Teléfono</h3>
                    <p>3154-6542515</p>
                    <p>+54 965542854</p>
                    <h3>Correo Electronico</h3>
                    <a href="http://hotmail.com/" target="_blank">barristar@outlook.com</a>
                </div><!-- Fin de columna izquierda -->

                <!-- Columna derecha -->
                <div class="columna">
                    <form id="formulario_contacto" action="" method="post">
                        <h3><b>Formulario de contacto rápido</b></h3>

                        <div class="entrada">
                            <input class="campo" type="text" 
                            placeholder="Nombres" id="txtnombres"
                            name="txtnombres">
                        </div>

                        <div class="entrada">
                            <input class="campo" type="text" 
                            placeholder="Apellidos" 
                            id="txtapellidos" name="txtapellidos">
                        </div>

                        <div class="entrada">
                            <input class="campo" type="text" 
                            placeholder="Correo electrónico" 
                            id="txtcorreo" name="txtcorreo">
                        </div> 
                        
                        <div class="entrada">
                            <input class="campo" type="tel" 
                            placeholder="Número de DNI" 
                            id="txtdni" name="txtdni">
                        </div>

                        <div class="entrada">
                            <input class="campo" type="tel" 
                            placeholder="Número de celular" 
                            id="txtcelular" name="txtcelular">
                        </div>

                        <div class="entrada">
                            <select class="campo" name="lstcarrera" id="lstcarrera">
                                <option value="" selected hidden>(Elige el tipo de ayuda)</option>
                                <option value="1">Ley Familiar</option>
                                <option value="2">Derecho Penal</option>
                                <option value="3">Lesiones Personales</option>
                                <option value="4">Derecho Empresarial</option>
                                <option value="5">Derecho inmobiliario</option>
                                <option value="6">Ley de Educación</option>
                            </select>
                        </div>

                    <textarea class="campo" cols="30" rows="10" placeholder="Deja tu mensaje" id="txtdescripcion" name="txtdescripcion"></textarea>
                    <p>
                        <input class="boton_enviar" type="submit" value="Enviar"  onclick="validacionformulario()">
                    </p>
                    
                    <p id="msjerror" class="error">
                    </p>
                    </form>
                <?php 
                    include("registro.php");
                ?>

                </div><!-- Fin del columna derecha -->

            </div><!-- Fin de fila -->
        </div><!-- Fin de contenedor -->

        <!-- Mapa -->
        <div class="mapa">
            <iframe class="ajustarmapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11033.883136852488!2d-77.04471150267601!3d-12.107579887841743!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xebe1baff9e8d505f!2sLinares%20Abogados!5e0!3m2!1ses-419!2spe!4v1663993117509!5m2!1ses-419!2spe" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div><!-- Fin de mapa -->
        
    </section><!-- Fin de contactarnos -->

    <!-- Pie de página -->
    <footer id="pie" class="pie">
        <!-- Contenedor -->
        <div class="contenedor">
            <!-- Fila Grupo 1  -->
            <div class="grupo-1">
                <!-- Columna izquierda -->
                <div>
                    <img src="imagenes/buffet.JPG" alt="">
                    <h2>BARRISTAR</h2>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Animi, at?</p>
                </div><!-- Fin de columna izquierda -->
                <!-- Primera columna del medio -->
                <div>
                    <h2>Enlace rápido</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis, provident. Tempora perspiciatis odit optio repellendus placeat animi omnis ullam vitae.</p>
                </div><!-- Fin de primera columna del medio -->
                <!-- Segunda columna del medio -->
                <div>
                    <h2>Área rapida</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, saepe.</p>
                </div><!-- Fin de segunda columna del medio -->
                <!-- Columna derecha -->
                <div>
                    <h2>Contáctenos</h2>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quis, sint!</p>
                </div><!-- Fin de columna derecha -->
            </div><!-- Fin de fila Grupo 1  -->
            <!-- Fila Grupo 2  -->
            <div  class="grupo-2">
                <!-- Fila -->
                <div class="fila">
                    <!-- Copyright -->
                    <div class="copyright">
                        &copy; Política de privaciadad<b>Slee Dw</b> 2022 - Barristar | Buffet de abagados.Reservados todos los derechos.
                    </div><!-- Fin de copyright -->
                    <!-- Redes Sociles -->
                    <div class="redes-sociales">
                        <a href="https://www.facebook.com/Abogados-Per%C3%BA-100104478015304" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                        <a href="https://twitter.com/search?q=%23abogado" target="_blank"><i class="fa-brands fa-twitter"></i></a>
                        <a href="https://www.instagram.com/gbmt.abogados/?hl=es" target="_blank"><i class="fa-brands fa-square-instagram"></i></a>
                    </div><!-- Fin de redes Sociles -->
                </div><!-- Fin de fila -->
            </div><!-- Fin de fila Grupo 2  -->
        </div><!-- Fin de contenedor -->
  </footer><!-- Fin de pie de página -->
    <a href="" id="boton-irArriba">
        <i class="fa-solid fa-angle-up"></i>
    </a>
</body>
</html>
<script src="scripts/boton-arriba.js"></script>
<script src="scripts/validar-formulario.js"></script>