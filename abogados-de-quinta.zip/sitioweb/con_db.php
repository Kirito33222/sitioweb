<?php
    $servidor="localhost";
    $usuario="root";
    $clave="";
    $basedatos = "bd_36617";

    $conex=mysqli_connect($servidor,$usuario,$clave,$basedatos);
?>